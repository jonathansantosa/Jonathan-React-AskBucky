######################################## Imports ########################################

import chromadb
import dotenv
import json
import openai
import os
import tiktoken

######################################## Client Creation ########################################

dotenv.load_dotenv('../.env')

openai_client = openai.OpenAI(api_key=os.environ.get("openai_api_key"))
chroma_client = chromadb.PersistentClient(path="data/chroma_client")

######################################## ChromaDB ########################################

def create_collection(name: str):
    return chroma_client.create_collection(name)

######################################## OpenAI ########################################

EMBEDDING_MODEL = "text-embedding-ada-002"
GPT_MODEL = "gpt-3.5-turbo"
MAX_TOKENS = 500
CHUNK_OVERLAP = 100

def num_tokens(text: str, model: str = GPT_MODEL) -> int:
    encoding = tiktoken.encoding_for_model(model)
    return len(encoding.encode(text))

def generate_chunks(input_string: str, max_tokens_per_chunk: int, chunk_overlap: int):
    tokens = input_string.split()  # Split the string into tokens (words)
    chunks = []
    current_chunk = []

    current_token_count = 0
    for token in tokens:
        token_count = num_tokens(token)
        if current_token_count + token_count <= max_tokens_per_chunk:
            current_chunk.append(token)
            current_token_count += token_count
        else:
            chunks.append(" ".join(current_chunk))
            current_chunk = current_chunk[chunk_overlap:]  # Apply overlap
            current_chunk.append(token)
            current_token_count = token_count

    if current_chunk:
        chunks.append(" ".join(current_chunk))

    return chunks

def generate_embeddings(datafile: str):
    embeddings_dict = {}
    with open(datafile, 'r') as df:
        data = json.load(df)
        for index in range(len(data)):
            vector_list = []
            chunks = generate_chunks(data[index]["content"], MAX_TOKENS, CHUNK_OVERLAP)
            for chunk in chunks:
                vector = openai_client.embeddings.create(
                    input=str(chunk),
                    model=EMBEDDING_MODEL
                ).data[0].embedding
                vector_list.append(vector)
            embeddings_dict[data[index]["url"]] = vector_list
    json_str = json.dumps(embeddings_dict, indent=1)
    with open("data/embeddings.json", 'w') as ef:
        ef.write(json_str)
    return json_str

def generate_response(query, context):
    request = [
        {"role": "system", "content": "You are a helpful AI assistant. You only use provided excerpts of text as context to answer a given question."},
        {"role": "user", "content": query},
        {"role": "user", "content": "Document: " + "\n".join(context[0])}
    ]
    response = openai_client.chat.completions.create(
        model="gpt-4",
        messages=request,
        temperature=0,
        max_tokens=1000
    ).choices[0].message.content
   
    # response_stream = ""
    # for letter in "".join(response):
    #     response_stream += letter + ""
    #     time.sleep(0.01)
    #     yield response_stream
    return response


if __name__ == "__main__":
    # generate_embeddings("data/output3.json")
    query = "List some of the services SCU offers"